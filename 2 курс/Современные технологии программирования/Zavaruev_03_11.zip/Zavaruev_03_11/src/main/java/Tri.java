public class Tri {
    public Tri() {
    }

    public double solve() {
        double left = 0;
        double right = 10;
        return this._solve(left, right);
    }

    private double _solve(double left, double right) {
        double pivot = (left + right) / 2;
        double guess = Math.cos(Math.pow(pivot, 5)) + Math.pow(pivot, 4) - 345.3 * pivot - 23;
        if (Math.abs(guess) < 0.001) {
            System.out.println("x:");
            System.out.println(pivot);
            System.out.println("Точность:");
            System.out.println(guess);
            return pivot;
        }
        System.out.println(pivot);
        if (guess > 0) {
            return this._solve(left, pivot);
        }
        return this._solve(pivot, right);

    }
}
