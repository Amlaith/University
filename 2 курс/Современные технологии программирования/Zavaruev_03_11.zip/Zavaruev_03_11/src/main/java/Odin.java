public class Odin {
    private int n;

    public Odin(int n) {
        this.n = n;
    }

    public void vyvod() {
        for (int i = 1; i < this.n; i++) {
            System.out.println(i);
        }
    }
}
