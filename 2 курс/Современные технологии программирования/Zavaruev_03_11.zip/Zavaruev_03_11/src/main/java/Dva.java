import java.util.Arrays;
import java.util.Random;

public class Dva {
    private int[] a;
    private int randBound = 10000000;

    public Dva(int n) {
        Random ran = new Random();
        this.a = new int[n];
        for (int j = 0; j < n; j++) {
            this.a[j] = ran.nextInt(randBound);
        }
    }

    public void show() {
        System.out.println(Arrays.toString(this.a));
    }

    public boolean binSearch(int target) {
        long start = System.nanoTime();
        int[] sorted = this.a;
        Arrays.sort(sorted);
        long sortedTime = System.nanoTime();
        int left = 0;
        int right = a.length;

        while (left < right) {
            int pivot = (int)(left + (right - left) / 2);
            int el = sorted[pivot];
            if (el == target) {
                System.out.println("Такой элемент есть, бинарный поиск занял " +  (System.nanoTime() - sortedTime) + "нс.");
                System.out.println("(Сортировка для бинарного поиска заняла " +  (sortedTime - start) + "нс.)");
                return true;
            }
            if (el < target) {
                left = pivot + 1;
            }
            if (el > target) {
                right = pivot;
            }
        }
        System.out.println("Такого элемента нет, бинарный поиск занял " +  (System.nanoTime() - sortedTime) + "нс.");
        System.out.println("(Сортировка для бинарного поиска заняла " +  (sortedTime - start) + "нс.)");
        return false;
    }

    public boolean linSearch(int target) {
        long start = System.nanoTime();
        for (int el: this.a) {
            if (el == target) {
                System.out.println("Такой элемент есть, линейный поиск занял " +  (System.nanoTime() - start) + "нс.");
                return true;
            }
        }
        System.out.println("Такого элемента нет, линейный поиск занял " +  (System.nanoTime() - start) + "нс.");
        return false;
    }
}

