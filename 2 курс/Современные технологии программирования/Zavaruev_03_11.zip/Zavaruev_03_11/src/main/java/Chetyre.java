public class Chetyre {
    public Node head;

    public Chetyre(int headValue) {
        this.head = new Node(headValue);
    }

    public void addNode(int value) {
        this._addNode(this.head, value);
    }

    private void _addNode(Node head, int value) {
        if (head.val > value) {
            if (head.left == null) {
                head.left = new Node(value);
            }
            else {
                this._addNode(head.left, value);
            }
        }
        else if (head.val < value) {
            if (head.right == null) {
                head.right = new Node(value);
            }
            else {
                this._addNode(head.right, value);
            }
        }
    }

    public void search(int target) {
        this._search(this.head, target);
    }

    private void _search(Node head, int target) {
        if (head.val == target) {
            System.out.println(target + " - Есть такой узел.");
        }
        else if ((head.val > target) && (head.left != null)) {
            this._search(head.left, target);
        }
        else if ((head.val < target) && (head.right != null)) {
            this._search(head.right, target);
        }
        else {
            System.out.println(target + " - Нет такого узла.");
        }
    }

    public void display() {
//        Взято из интернетов https://rosettacode.org/wiki/Visualize_a_tree#Java
        final int height = 5, width = 64;

        int len = width * height * 2 + 2;
        StringBuilder sb = new StringBuilder(len);
        for (int i = 1; i <= len; i++)
            sb.append(i < len - 2 && i % width == 0 ? "\n" : ' ');

        displayR(sb, width / 2, 1, width / 4, width, this.head, " ");
        System.out.println(sb);
    }

    private void displayR(StringBuilder sb, int c, int r, int d, int w, Node n,
                          String edge) {
        if (n != null) {
            displayR(sb, c - d, r + 2, d / 2, w, n.left, " /");

            String s = String.valueOf(n.val);
            int idx1 = r * w + c - (s.length() + 1) / 2;
            int idx2 = idx1 + s.length();
            int idx3 = idx1 - w;
            if (idx2 < sb.length())
                sb.replace(idx1, idx2, s).replace(idx3, idx3 + 2, edge);

            displayR(sb, c + d, r + 2, d / 2, w, n.right, "\\ ");
        }
    }

}
