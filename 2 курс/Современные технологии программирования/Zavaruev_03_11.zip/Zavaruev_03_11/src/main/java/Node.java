public class Node {
    public int val;
    public Node left;
    public Node right;

    public Node(int value) {
        this.val = value;
        this.left = null;
        this.right = null;
    }
}
