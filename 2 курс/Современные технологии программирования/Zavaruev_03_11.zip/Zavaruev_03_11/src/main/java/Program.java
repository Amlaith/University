public class Program {
    public static void main(String[] args) {
//        Задание 1. Вывод от 1 до n.
        Odin chisla = new Odin(7);
        chisla.vyvod();


////        Задание 2. Бинарный и линейный поиски по массиву.
//        Dva massiv = new Dva(10000000);
////        massiv.show();
//        massiv.binSearch(644);
//        massiv.linSearch(644);


////        Задание 3. Поиск решения уравнения делением отрезка пополам. Точность не хуже 0.001.
//        Tri reshala = new Tri();
//        reshala.solve();



////        Задание 4. Бинарное дерево поиска.
//        Chetyre derevo = new Chetyre(10);
//        derevo.addNode(5);
//        derevo.addNode(6);
//        derevo.addNode(8);
//        derevo.addNode(3);
//        derevo.addNode(1);
//        derevo.addNode(4);
//        derevo.addNode(12);
//        derevo.addNode(23);
//        derevo.addNode(23);
//
//        derevo.display();
//
//        derevo.search(3);
//        derevo.search(19);
    }
}
