import java.util.Scanner;

public class Program {
    public static void main(String[] args) {

//        Создается экземпляр сканера ввода
        Scanner scanner = new Scanner(System.in);

//        Вывод начальной инструкции
        System.out.println("===========================================================");
        System.out.println("Введите выражение вида: 'Тридцать восемь умножить на пять'.");
        System.out.println("Для выхода введите 'Выход'.");

//        Первый ввод принимается и переводится в нижний регистр
        String input = scanner.nextLine().toLowerCase();

//        Запускается цикл, работающий до тех пор, пока не введут команду "выход" или "в"
        while (!input.equals("выход") && !input.equals("в")) {
            System.out.println(Calculator.calc(input)); // Метод Calculator.calc возвращает ответ в виде строки
            System.out.println("==========================================================="); // Приглашение к
            System.out.println("Введите следующее выражение или введите 'Выход' для выхода."); // следующему вводу
            input = scanner.nextLine().toLowerCase(); // Следующий ввод принимается и переводится в нижний регистр
        }
    }
}
