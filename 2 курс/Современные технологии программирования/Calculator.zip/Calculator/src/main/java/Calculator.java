
//    Класс, считающий результат выражения

public class Calculator {
    public static String calc(String input) {
//        Сообщение об ошибке
        String error = "В введенной строке ошибка.\nКалькулятор правильно работает с числами от 0 до 99.\nНаписание операторов: 'плюс', 'минус', 'умножить на', 'делить на'.";

//        Введенная строка по оператору разбивается на два числа
        String[] operands = input.split(" плюс | минус | делить на | умножить на ");

//        Если разбиением получилось не две строки - возвращается сообщение об ошибке
        if (operands.length != 2) {
            return error;
        }

//        Converter.strToInt делает из строкового представления числа цифровое
        Integer operator1 = Converter.strToInt(operands[0]);
        Integer operator2 = Converter.strToInt(operands[1]);

//        strToInt возвращает 99999, если не смог распознать число
//        В таком случае тоже возвращается сообщение об ошибке
        if (operator1 + operator2 > 2000) {
            return error;
        }

//        Переменная для результата вычисления
        Integer res = null;

//        Оператор выбирается по букве во введенной строке после первого числа и пробела
//        (напр. 'сорок два ->м<-инус четыре')
        switch (input.charAt(operands[0].length()+1)) {
            case 'п': // Если 'п' - плюс - операторы складываются и т.д.
                res = operator1 + operator2;
                break;

            case 'м':
                res = operator1 - operator2;
                break;

            case 'у':
                res = operator1 * operator2;
                break;

            case 'д':
                res = operator1 / operator2;
                break;
        }

//        Возвращается результат вычисления,
//        предварительно переведенный в строку
        return Converter.intToStr(res);
    }
}
