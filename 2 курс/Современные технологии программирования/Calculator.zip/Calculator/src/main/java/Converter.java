import java.util.HashMap;
import java.util.Map;

// Класс, переводящий число из строкового представления в числовое и наоборот

public class Converter {
//    Это действительно самый простой способ сделать словарь?.. 0_о
    private static final Map<String, Integer> CHISLA;
    static  {
        CHISLA = new HashMap<String, Integer>();
        CHISLA.put("ноль", 0);
        CHISLA.put("один", 1);
        CHISLA.put("два", 2);
        CHISLA.put("три", 3);
        CHISLA.put("четыре", 4);
        CHISLA.put("пять", 5);
        CHISLA.put("шесть", 6);
        CHISLA.put("семь", 7);
        CHISLA.put("восемь", 8);
        CHISLA.put("девять", 9);
        CHISLA.put("десять", 10);
        CHISLA.put("одиннадцать", 11);
        CHISLA.put("двенадцать", 12);
        CHISLA.put("тринадцать", 13);
        CHISLA.put("четырнадцать", 14);
        CHISLA.put("пятнадцать", 15);
        CHISLA.put("шестнадцать", 16);
        CHISLA.put("семнадцать", 17);
        CHISLA.put("восемнадцать", 18);
        CHISLA.put("девятнадцать", 19);
        CHISLA.put("двадцать", 20);
        CHISLA.put("тридцать", 30);
        CHISLA.put("сорок", 40);
        CHISLA.put("пятьдесят", 50);
        CHISLA.put("шестьдесят", 60);
        CHISLA.put("семьдесят", 70);
        CHISLA.put("восемьдесят", 80);
        CHISLA.put("девяносто", 90);
        CHISLA.put("сто", 100);
        CHISLA.put("двести", 200);
        CHISLA.put("триста", 300);
        CHISLA.put("четыреста", 400);
        CHISLA.put("пятьсот", 500);
        CHISLA.put("шестьсот", 600);
        CHISLA.put("семьсот", 700);
        CHISLA.put("восемьсот", 800);
        CHISLA.put("девятьсот", 900);
        CHISLA.put("тысяча", 1000);
        CHISLA.put("две тысячи", 2000);
        CHISLA.put("три тысячи", 3000);
        CHISLA.put("четыре тысячи", 4000);
        CHISLA.put("пять тысяч", 5000);
        CHISLA.put("шесть тысяч", 6000);
        CHISLA.put("семь тысяч", 7000);
        CHISLA.put("восемь тысяч", 8000);
        CHISLA.put("девять тысяч", 9000);
    }

//    Метод перевода числа из строкового представления в цифровое
    public static Integer strToInt(String strVal) {
        int intVal = 0; // Переменная для получившегося числа
        for (String num: strVal.split(" ")) { // Строка с числом разбивается на отдельные слова
            Integer fetched = CHISLA.get(num.toLowerCase()); // Каждое слово ищется в словаре CHISLA
            if (fetched == null) { // Если не нашлось - возвращается код ошибки
                return 99999;
            }
            intVal += fetched; // Если все хорошо - значение слова прибавляется к значению числа
        }
        return intVal; // Цифровое значение числа возвращается
    }

//    Метод перевода числа из цифрового представления в строковое
    public static String intToStr(Integer intVal) {
        if (intVal == 0) { // Отдельный иф для значения ноль, чтобы не путаться с нулем в середине числа
            return "ноль";
        }

//        Переводится положительное число, минус добавляется к строке потом
        int posVal = Math.abs(intVal);

//        Переменная для итоговой строки
        String strVal = "";
//        Счетчик разряда цифры
        int digit = 0;

//        Если две последние цифры числа - число от 11 до 19,
//        они представляют одно слово и обрабатываются вместе
        int target = posVal % 100; // Последние две цифры
        if (target > 10 && target < 20) { // Если они от 11 до 19
            for (Map.Entry<String, Integer> entry : CHISLA.entrySet()) { // Проход по паре ключ-значение в CHISLA
                if (entry.getValue().equals(target)) { // Когда значение (число) совпадает
                    strVal = entry.getKey(); // В strVal записывается ключ (строковое представление числа)
                }
            }
            digit += 2; // Обработаны сразу две цифры - счетчик разряда увеличивается на два, ...
            posVal /= 100; // ... а число сдвигается на два знака вправо
        }

//        Цикл проходит по числу справа налево
//        Пока в числе есть цифры, последняя из них обрабатывается и отсекается,
//        а в начало строки записыватся слово, эту цифру обозначающее
        while (posVal > 0) {
//            Число для поиска в CHISLA: последняя цифра умножается на 10 в степени текущего разряда
            target = (int) ((posVal % 10) * Math.pow(10, digit));
            if (target > 0) { // Ноль в середине числа никак записывать не надо
                for (Map.Entry<String, Integer> entry : CHISLA.entrySet()) { // Проход по паре ключ-значение в CHISLA
                    if (entry.getValue().equals(target)) { // Когда значение (число) совпадает...
//                        ... в начало strVal добавляется ключ (строковое представление числа)
                        strVal = entry.getKey() + " " + strVal;
                    }
                }
            }
            digit += 1; // Разряд увеличиватся на один
            posVal = posVal / 10; // Число сдвигается на знак вправо
        }

//        Если число отрицательное, в начало strVal добавляется слово "минус"
        if (intVal < 0) {
            strVal = "минус " + strVal;
        }

//        В строковом представлении числа первая буква меняется на большую,
//        удаляются лишние пробелы, и оно возвращается
        return strVal.substring(0, 1).toUpperCase() + strVal.trim().substring(1);
    }
}
